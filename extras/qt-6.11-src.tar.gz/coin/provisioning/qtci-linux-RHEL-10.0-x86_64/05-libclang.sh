#!/usr/bin/env bash
#Copyright (C) 2026 The Qt Company Ltd
#SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
set -ex

BASEDIR=$(dirname "$0")
# shellcheck source=../common/unix/libclang.sh
"$BASEDIR/../common/unix/libclang.sh"
