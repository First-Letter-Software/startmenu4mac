#!/bin/bash
#Copyright (C) 2025 The Qt Company Ltd
#SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only

BASEDIR=$(dirname "$0")
"$BASEDIR/../common/unix/install_openapi.sh"

